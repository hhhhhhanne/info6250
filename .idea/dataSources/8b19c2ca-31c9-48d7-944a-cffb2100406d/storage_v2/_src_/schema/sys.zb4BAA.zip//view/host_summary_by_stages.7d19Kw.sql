CREATE VIEW host_summary_by_stages AS
  SELECT
    if(isnull(`performance_schema`.`events_stages_summary_by_host_by_event_name`.`HOST`), 'background',
       `performance_schema`.`events_stages_summary_by_host_by_event_name`.`HOST`)                            AS `host`,
    `performance_schema`.`events_stages_summary_by_host_by_event_name`.`EVENT_NAME`                          AS `event_name`,
    `performance_schema`.`events_stages_summary_by_host_by_event_name`.`COUNT_STAR`                          AS `total`,
    `sys`.`format_time`(
        `performance_schema`.`events_stages_summary_by_host_by_event_name`.`SUM_TIMER_WAIT`)                 AS `total_latency`,
    `sys`.`format_time`(
        `performance_schema`.`events_stages_summary_by_host_by_event_name`.`AVG_TIMER_WAIT`)                 AS `avg_latency`
  FROM `performance_schema`.`events_stages_summary_by_host_by_event_name`
  WHERE (`performance_schema`.`events_stages_summary_by_host_by_event_name`.`SUM_TIMER_WAIT` <> 0)
  ORDER BY if(isnull(`performance_schema`.`events_stages_summary_by_host_by_event_name`.`HOST`), 'background',
              `performance_schema`.`events_stages_summary_by_host_by_event_name`.`HOST`),
    `performance_schema`.`events_stages_summary_by_host_by_event_name`.`SUM_TIMER_WAIT` DESC;

